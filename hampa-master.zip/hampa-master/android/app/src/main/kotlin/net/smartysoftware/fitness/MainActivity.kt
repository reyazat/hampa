package net.smartysoftware.fitness

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
