import 'package:fitness/values/colors.dart';
import 'package:fitness/widgets/buttons.dart';
import 'package:fitness/widgets/rounded_text_field.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        minimum: const EdgeInsets.symmetric(horizontal: 15),
        child: Column(
          children: <Widget>[
            Expanded(
              child: Column(
                children: <Widget>[
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 60),
                    child: Text(
                      'ورود | ثبت نام',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 32,
                        color: MainColors.grayDarkest,
                      ),
                    ),
                  ),
                  RoundedTextField(hint: 'شماره موبایل'),
                ],
              ),
            ),
            const FilledRoundedButton(label: 'ورود'),
            Padding(
                padding: const EdgeInsets.symmetric(vertical: 15),
                child: RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    text: 'ورود/ثبت نام به منزله پذیرش\n',
                    style: const TextStyle(
                      color: MainColors.grayDarkest,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Shabnam',
                    ),
                    children: <TextSpan>[
                      TextSpan(
                        text: 'شرایط استفاده',
                        recognizer: TapGestureRecognizer()..onTap = () {},
                        style: const TextStyle(fontWeight: FontWeight.w700, color: MainColors.primaryColor),
                      ),
                      const TextSpan(text: ' و '),
                      TextSpan(
                        text: 'حریم خصوصی',
                        recognizer: TapGestureRecognizer()..onTap = () {},
                        style: const TextStyle(fontWeight: FontWeight.w700, color: MainColors.primaryColor),
                      ),
                      const TextSpan(text: ' است'),
                    ],
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
