import 'package:fitness/values/colors.dart';
import 'package:fitness/widgets/app_bar.dart';
import 'package:fitness/widgets/music_item.dart';
import 'package:fitness/widgets/rounded_card.dart';
import 'package:flutter/material.dart';

class MusicScreen extends StatelessWidget {
  const MusicScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(title: 'آهنگ ها'),
      body: SafeArea(
        minimum: const EdgeInsets.symmetric(horizontal: 15),
        child: Column(
          children: [
            RoundedCard(
              margin: const EdgeInsets.only(bottom: 10),
              color: MainColors.primaryColor,
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const <Widget>[
                        Text(
                          'پلی لیست من',
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: Colors.white),
                        ),
                        SizedBox(height: 5),
                        Text(
                          '۱۲ آهنگ',
                          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                  GestureDetector(
                    child: const Icon(Icons.play_circle_outlined, color: Colors.white, size: 35),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                children: const [
                  MusicItem(name: 'موزیک ورزشی ۱', duration: 2),
                  MusicItem(name: 'موزیک ورزشی ۲', duration: 2),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
