import 'package:fitness/models/training.dart';
import 'package:fitness/screens/training_details.dart';
import 'package:fitness/utils/num_api.dart';
import 'package:fitness/values/colors.dart';
import 'package:fitness/widgets/bottom_nav_icon.dart';
import 'package:fitness/widgets/drop_down_menu.dart';
import 'package:fitness/widgets/gradient_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class TrainingPage extends StatelessWidget {
  const TrainingPage();

  @override
  Widget build(BuildContext context) {
    /// TODO: Remove this after connecting app to REST api
    var trainingModel = TrainingModel(
      'آموزش رول شکم',
      'حامد جعفرزاده',
      'یکی از ساده‌ترین روش تمرین دادن شکم ، دست و پا استفاده از چرخ تمرین شکم است. امروزه رولر تناسب اندام یا چرخ تمرین شکم یکی از لوازم ورزشی بسیار مفید در تناسب اندام و تقویت عضلات ماهیچه شکم پشت بازوها و شانه ها و حتی پا می‌باشد.',
      'assets/images/train1.jpg',
      '',
      30,
    );

    return Column(
      children: <Widget>[
        SizedBox(
          height: 120,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: const [
              Padding(
                padding: EdgeInsets.only(left: 30),
                child: BottomNavigationIcon(label: 'همه', icon: Icons.grid_view, isActive: true),
              ),
              Padding(
                padding: EdgeInsets.only(left: 30),
                child: BottomNavigationIcon(label: 'یوگا', icon: Icons.self_improvement),
              ),
              Padding(
                padding: EdgeInsets.only(left: 30),
                child: BottomNavigationIcon(label: 'گرم کردن', icon: Icons.directions_run),
              ),
              Padding(
                padding: EdgeInsets.only(left: 30),
                child: BottomNavigationIcon(label: 'قدرتی', icon: Icons.fitness_center),
              ),
              Padding(
                padding: EdgeInsets.only(left: 0),
                child: BottomNavigationIcon(label: 'کششی', icon: Icons.sports_gymnastics),
              ),
            ],
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            DropDownMenu(
              items: const [
                'جدید ترین',
                'محبوب ترین',
                'آسان ترین',
              ],
              onChange: () {},
            ),
            const Text(
              'فیلتر',
              style: TextStyle(color: MainColors.primaryColor, fontWeight: FontWeight.w600, fontSize: 15),
            ),
          ],
        ),
        const SizedBox(height: 20),
        GradiantImage(
          imageUrl: 'assets/images/train1.jpg',
          onTap: () => Get.to(() => TrainingDetailsScreen(trainingModel)),
          label: Padding(
            padding: const EdgeInsets.all(10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      trainingModel.title,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 16),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      trainingModel.trainer,
                      style: const TextStyle(color: Colors.white),
                    ),
                  ],
                ),
                Text(
                  '${trainingModel.duration.toFaString()} دقیقه',
                  style: const TextStyle(color: Colors.white),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
