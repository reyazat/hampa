import 'dart:ui';

class MainColors {
  static const primaryColor = Color(0xFFDD2D6C);
  static const grayLightest = Color(0xFFEEEEEE);
  static const grayLight = Color(0xFFD9D9D9);
  static const grayMid = Color(0xFFA5A5A5);
  static const grayDark = Color(0xFF666666);
  static const grayDarkest = Color(0xFF444444);
}