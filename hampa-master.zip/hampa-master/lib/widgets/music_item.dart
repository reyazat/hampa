import 'package:fitness/utils/num_api.dart';
import 'package:fitness/values/colors.dart';
import 'package:fitness/widgets/rounded_card.dart';
import 'package:flutter/material.dart';

class MusicItem extends StatelessWidget {
  final String name;
  final int duration;

  const MusicItem({required this.name, required this.duration});

  @override
  Widget build(BuildContext context) {
    return RoundedCard(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  name,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                    color: MainColors.primaryColor,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  '${duration.toFaString()} دقیقه',
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                    color: MainColors.grayDarkest,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            child: const Icon(
              Icons.playlist_add,
              color: MainColors.primaryColor,
              size: 30,
            ),
          ),
          const SizedBox(width: 10),
          GestureDetector(
            child: const Icon(
              Icons.play_circle_outlined,
              color: MainColors.primaryColor,
              size: 35,
            ),
          ),
        ],
      ),
    );
  }
}
